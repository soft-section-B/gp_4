package employeesalarymanagement;

 import java.io.*;
import java.util.*;

    public class EmployeeSalaryManagemen{
    private static final double TAX_RATE = 0.15; // 15% income tax
    private static final double PENSION_RATE = 0.07; // 7% pension

    private static class Employee {
        String name;
        double salary;
        double incomeTax;
        double pension;
        double netSalary;

        Employee(String name, double salary) {
            this.name = name;
            this.salary = salary;
            calculateDeductions();
        }

        void calculateDeductions() {
            this.incomeTax = salary * TAX_RATE;
            this.pension = salary * PENSION_RATE;
            this.netSalary = salary - incomeTax - pension;
        }

        @Override
        public String toString() {
            return String.format("%s: Salary=%.2f, Tax=%.2f, Pension=%.2f, Net Salary=%.2f",
                    name, salary, incomeTax, pension, netSalary);
        }
    }

    private static Map<String, Employee> employees = new HashMap<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Add Employee");
            System.out.println("2. Update Employee");
            System.out.println("3. Display Employees");
            System.out.println("4. Save to File");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addEmployee(scanner);
                    break;
                case 2:
                    updateEmployee(scanner);
                    break;
                case 3:
                    displayEmployees();
                    break;
                case 4:
                    saveToFile();
                    break;
                case 5:
                    System.out.println("Exiting the program...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void addEmployee(Scanner scanner) {
        System.out.print("Enter employee name: ");
        String name = scanner.nextLine();
        if (employees.containsKey(name)) {
            System.out.println("The name is used by another employee. Please input a unique name.");
            return;
        }
        System.out.print("Enter employee salary: ");
        double salary = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        employees.put(name, new Employee(name, salary));
        System.out.println("Employee added successfully.");
    }

    private static void updateEmployee(Scanner scanner) {
        System.out.print("Enter the name of the employee to update: ");
        String name = scanner.nextLine();
        if (!employees.containsKey(name)) {
            System.out.println("Employee not found.");
            return;
        }
        System.out.print("Enter new name (or press Enter to keep current name): ");
        String newName = scanner.nextLine();
        if (!newName.isEmpty() && employees.containsKey(newName)) {
            System.out.println("The name is used by another employee. Update canceled.");
            return;
        }
        System.out.print("Enter new salary: ");
        double salary = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        Employee employee = employees.remove(name);
        if (!newName.isEmpty()) {
            employee.name = newName;
        }
        employee.salary = salary;
        employee.calculateDeductions();
        employees.put(employee.name, employee);
        System.out.println("Employee updated successfully.");
    }

    private static void displayEmployees() {
        if (employees.isEmpty()) {
            System.out.println("No employees to display.");
            return;
        }
        System.out.println("\nEmployee List:");
        for (Employee employee : employees.values()) {
            System.out.println(employee);
        }
    }

    private static void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("employees.txt"))) {
            for (Employee employee : employees.values()) {
                writer.write(employee.toString());
                writer.newLine();
            }
            System.out.println("Employees saved to file successfully.");
        } catch (IOException e) {
            System.out.println("Error saving to file: " + e.getMessage());
        }
    }
    }

