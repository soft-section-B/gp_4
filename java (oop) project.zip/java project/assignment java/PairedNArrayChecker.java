import java.util.Scanner;

public class PairedNArrayChecker {

    
    public static int isPairedN(int[] a, int n) {
        // Pre-check conditions before entering loops
        if (a == null || a.length < 2 || n < 0 || n > (a.length - 1) * 2) {
            return 0;
        }

        // Check all possible pairs
        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (i + j == n && a[i] + a[j] == n) {
                    return 1;  // Return immediately when found
                }
            }
        }
        
        return 0;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get array from user
        System.out.print("Enter array size: ");
        int size = scanner.nextInt();
        
        if (size < 2) {
            System.out.println("Array must have at least 2 elements");
            return;
        }
        
        int[] array = new int[size];
        System.out.println("Enter " + size + " integers:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }
        
        // Get N value from user
        System.out.print("Enter N value: ");
        int n = scanner.nextInt();
        
        // Check and display result
        int result = isPairedN(array, n);
        System.out.println("\nResult: " + result);
        System.out.println("(1 = paired-N, 0 = not paired-N)");
        
        scanner.close();
    }
}