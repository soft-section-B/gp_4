import java.util.Scanner;

public class NonZeroAverageCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] A = new double[20];
        
        // Get input from user
        System.out.println("Enter 20 numbers (can be zero or non-zero):");
        for (int i = 0; i < A.length; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            A[i] = scanner.nextDouble();
        }
        
        // Calculate average of non-zero numbers
        double sum = 0.0;
        int count = 0;
        
        for (double num : A) {
            if (num != 0.0) {
                sum += num;
                count++;
            }
        }
        
        // Compute and display result
        if (count > 0) {
            double average = sum / count;
            System.out.printf("Average of non-zero numbers: %.2f%n", average);
            System.out.println("Number of non-zero elements: " + count);
        } else {
            System.out.println("All numbers were zero - cannot compute average.");
        }
        
        scanner.close();
    }
}
