
import java.util.Scanner;

public class FactorCountComparator {

    /**
     * Returns 1 if both numbers have the same number of factors,
     * -1 if either is negative, 0 otherwise
     */
    public static int sameNumberOfFactors(int n1, int n2) {
        // Check for negative numbers
        if (n1 < 0 || n2 < 0) {
            return -1;
        }
        
        // Special case: if numbers are equal (including 0 == 0)
        if (n1 == n2) {
            return 1;
        }
        
        // Count factors for each number
        int count1 = countFactors(n1);
        int count2 = countFactors(n2);
        
        return (count1 == count2) ? 1 : 0;
    }

    /** Helper method to count factors of a number */
    private static int countFactors(int num) {
        if (num == 0) return 0;  // 0 has infinite factors, treated as 0
        if (num == 1) return 1;   // 1 has only itself as a factor
        
        int count = 2; // Start with 1 and the number itself
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter two integers:");
        System.out.print("First number: ");
        int num1 = scanner.nextInt();
        
        System.out.print("Second number: ");
        int num2 = scanner.nextInt();
        
        int result = sameNumberOfFactors(num1, num2);
        
        System.out.println("\nResult: " + result);
        System.out.println("(1 = same factors, 0 = different, -1 = negative input)");
        
        scanner.close();
    }
}
