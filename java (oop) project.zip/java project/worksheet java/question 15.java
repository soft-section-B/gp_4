import java.util.Scanner;

public class OddEvenDifference {

    // Function to calculate X - Y where X is sum of odds, Y is sum of evens
    public static int f(int[] a) {
        int sumOdd = 0;
        int sumEven = 0;
        
        for (int num : a) {
            if (num % 2 != 0) {
                sumOdd += num;  // Add to odd sum
            } else {
                sumEven += num; // Add to even sum
            }
        }
        
        return sumOdd - sumEven;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get array size from user
        System.out.print("Enter the number of elements in the array: ");
        int size = scanner.nextInt();
        
        // Validate size
        if (size <= 0) {
            System.out.println("Array size must be positive.");
            return;
        }
        
        // Get array elements from user
        int[] numbers = new int[size];
        System.out.println("Enter " + size + " integers:");
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }
        
        // Calculate and display result
        int result = f(numbers);
        System.out.println("The difference (sum of odds - sum of evens) is: " + result);
        
        scanner.close();
    }
}
