public class Counter {
    private int value;  // Private instance variable to store the counter value

    // Constructor initializes counter to 0
    public Counter() {
        value = 0;
    }

    // Increments the counter value by 1
    public void increment() {
        value++;
    }

    // Returns the current counter value
    public int getValue() {
        return value;
    }
}