import java.util.Scanner;

public class FibonacciFinder {
    
    /**
     * Finds the largest Fibonacci number less than or equal to n
     * @param n The target number
     * @return The closest Fibonacci number <= n, or 0 if n < 1
     */
    public static int closestFibonacci(int n) {
        if (n < 1) return 0;
        
        int a = 1;  // First Fibonacci number
        int b = 1;  // Second Fibonacci number
        
        // Generate Fibonacci numbers until we exceed n
        while (b <= n) {
            int next = a + b;
            a = b;
            b = next;
        }
        
        return a;  // Returns the largest Fibonacci <= n
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a positive integer: ");
        while (!scanner.hasNextInt()) {
            System.out.println("Please enter a valid integer!");
            scanner.next();
            System.out.print("Enter a positive integer: ");
        }
        
        int input = scanner.nextInt();
        int result = closestFibonacci(input);
        
        System.out.println("The closest Fibonacci number <= " + input + " is: " + result);
        
        scanner.close();
    }
}
