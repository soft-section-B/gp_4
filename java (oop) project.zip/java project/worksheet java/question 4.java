import java.util.Scanner;

public class FindLargestNumber {

    
    public static int findLargest(int[] arr) {
        // Check for null or empty array
        if (arr == null || arr.length == 0) {
            throw new IllegalArgumentException("Array must not be null or empty");
        }
        
        // Initialize max with the first element
        int max = arr[0];
        
        // Compare with remaining elements
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        
        return max;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get array size from user
        System.out.print("Enter the number of elements in the array: ");
        int size = scanner.nextInt();
        
        // Validate size
        if (size <= 0) {
            System.out.println("Array size must be a positive integer.");
            scanner.close();
            return;
        }
        
        // Create array and get elements from user
        int[] numbers = new int[size];
        System.out.println("Enter " + size + " integers:");
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }
        
        // Find and display the largest number
        try {
            int largest = findLargest(numbers);
            System.out.println("The largest number in the array is: " + largest);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        scanner.close();
    }
}