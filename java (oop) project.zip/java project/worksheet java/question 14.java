import java.util.Scanner;

public class PrimeHappyChecker {

    public static int isPrimeHappy(int n) {
        if (n < 2) {
            return 0;  // No primes less than 2
        }

        int sum = 0;
        boolean hasPrime = false;

        // Check all numbers less than n
        for (int i = 2; i < n; i++) {
            if (isPrime(i)) {
                hasPrime = true;
                sum += i;
            }
        }

        // Return 1 if at least one prime exists and sum is divisible by n
        return (hasPrime && sum % n == 0) ? 1 : 0;
    }

    // Helper function to check if a number is prime
    private static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a positive integer: ");
        int number = scanner.nextInt();
        
        int result = isPrimeHappy(number);
        
        if (result == 1) {
            System.out.println(" 1");
        } else {
            System.out.println(" 0");
        }
        
        scanner.close();
    }
}