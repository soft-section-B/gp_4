import java.util.Scanner;
import java.util.HashMap;

public class SteppedArrayCheckere {

    public static int isStepped(int[] a) {
        // Check if array is in ascending order
        for (int i = 0; i < a.length - 1; i++) {
            if (a[i] > a[i + 1]) {
                return 0; // Not in ascending order
            }
        }

        // Count occurrences of each value
        HashMap<Integer, Integer> countMap = new HashMap<>();
        for (int num : a) {
            countMap.put(num, countMap.getOrDefault(num, 0) + 1);
        }

        // Check if all distinct values have at least 3 occurrences
        for (int count : countMap.values()) {
            if (count < 3) {
                return 0;
            }
        }

        return 1; // All conditions satisfied
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        int[] array = new int[size];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        int result = isStepped(array);
        System.out.println( "the result is"+(result == 1 ? "1" : "0"));

        scanner.close();
    }
}
