public class MultiplesOfThree {
    public static void main(String[] args) {
        // Loop from 3 to 36, incrementing by 3 each time
        for (int i = 3; i <= 36; i += 3) {
            System.out.print(i + " ");
        }
    }
}
