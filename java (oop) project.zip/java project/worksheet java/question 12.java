import java.util.Random;

public class PairOfDice {
    // Private instance variables
    private int die1;
    private int die2;
    private Random random;
    private int rollCount;

    // Constructor initializes the dice
    public PairOfDice() {
        random = new Random();
        rollCount = 0;
        roll(); // Initial roll
    }

    // Roll both dice
    public void roll() {
        die1 = random.nextInt(6) + 1;
        die2 = random.nextInt(6) + 1;
        rollCount++;
    }

    // Getter methods
    public int getDie1() {
        return die1;
    }

    public int getDie2() {
        return die2;
    }

    public int getTotal() {
        return die1 + die2;
    }

    public int getRollCount() {
        return rollCount;
    }

    // String representation of the dice
    @Override
    public String toString() {
        return "Die 1: " + die1 + ", Die 2: " + die2 + " (Total: " + getTotal() + ")";
    }
}
