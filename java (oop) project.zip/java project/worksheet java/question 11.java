import java.util.Scanner;

class Employee {
    String lastName;
    String firstName;
    double hourlyWage;
    int yearsWithCompany;
}

public class EmployeeReport {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Employee[] employeeData = new Employee[100];
        
        // Input employee data
        for (int i = 0; i < employeeData.length; i++) {
            System.out.println("\nEnter details for Employee #" + (i + 1));
            employeeData[i] = new Employee();
            
            System.out.print("First Name: ");
            employeeData[i].firstName = scanner.nextLine();
            
            System.out.print("Last Name: ");
            employeeData[i].lastName = scanner.nextLine();
            
            System.out.print("Hourly Wage: ");
            employeeData[i].hourlyWage = Double.parseDouble(scanner.nextLine());
            
            System.out.print("Years with Company: ");
            employeeData[i].yearsWithCompany = Integer.parseInt(scanner.nextLine());
        }
        
        // Display employees with 20+ years of service
        System.out.println("\nEmployees with 20+ years of service:");
        System.out.println("-----------------------------------");
        
        for (Employee emp : employeeData) {
            if (emp.yearsWithCompany >= 20) {
                System.out.printf("%s %s, Wage: $%.2f/hour%n",
                    emp.firstName, emp.lastName, emp.hourlyWage);
            }
        }
        
        scanner.close();
    }
}