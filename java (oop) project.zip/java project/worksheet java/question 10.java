
public class Main {
    public static void main(String[] args) {
        Counter myCounter = new Counter();  // Starts at 0
        
        myCounter.increment();  // Now 1
        myCounter.increment();  // Now 2
        myCounter.increment();  // Now 3
        System.out.println("Current value: " + myCounter.getValue());  // Output: 3
    }
}
